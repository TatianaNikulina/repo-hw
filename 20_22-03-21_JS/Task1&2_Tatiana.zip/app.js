/* Task1 (1. Написать скрипт, который будет ждать от пользователя ввода числа с клавиатуры, 
   сравнивать с заранее определенным числом в коде. Если число пользователя меньше, то 
   показывать alert с указанием "Меньше", если больше - "Больше" и ждать нового 
   ввода числа. Если пользователь угадал число - поздравить и закончить выполнение 
   скрипта.) */

let value = 60;
let result = +prompt("Please write a number");
while (result !== value) {
  result < value
    ? alert("Your number is less")
    : alert("Your number is greater");
  //   if (result < value) {
  //     alert("Your number is less");
  //   } else {
  //     alert("Your number is greater");
  //   }
  result = +prompt("Please write a new number");
}
if (result === value) {
  alert(`Congratulations. You guessed the number! It is ${result}.`);
}

/* Task2 (2.Реализовать таблицу умножения в виде многомерного массива. После этой реализации 
   любой запрос к элементам этого массива должен возвращать произведение его индексов.*/
// let n = +prompt("Введите размер квадратной матрицы");
// let matrix = [];
// for (let i = 0; i < n; i++) {
//   matrix.push(i);
//   matrix[i] = [];
//   for (let j = 0; j < n; j++) {
//     matrix[i].push(j);
//     matrix[i][j] = i * j;
//   }
// }
// console.log(matrix);
