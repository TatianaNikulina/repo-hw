const team = {
  teamName: "LadiesWithBall",
  year: 2021,
  town: "Ryazan",
  //   teamRole: ["goalkeepers", "defenders", "midfielders", "forwards", "coach"],
};
console.log(team);

team.members = [];

const goalkeepers = {
  memberName: "Player_1",
  age: 21,
  deadline: 2025,
};

const defenders = {
  memberName: "Player_4",
  age: 20,
  deadline: 2023,
};

const midfielders = {
  memberName: "Player_11",
  age: 19,
  deadline: 2022,
};

const forwards = {
  memberName: "Player_19",
  age: 18,
  deadline: 2024,
};

const coach = {
  memberName: "Player_23",
  age: 25,
  deadline: 2026,
};

team.members.push(goalkeepers, defenders, midfielders, forwards, coach);

console.log(team);
