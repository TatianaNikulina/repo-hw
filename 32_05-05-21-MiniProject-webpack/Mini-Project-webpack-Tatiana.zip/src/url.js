const URL = "https://jsonplaceholder.typicode.com";

export { URL };
